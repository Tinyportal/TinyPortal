<?php
/******************************************************************************
* TPmainmenu_hook.php                                                                 *
*******************************************************************************
* TP version: 1.0 beta 5                                                                                                      *
* Software Version:           SMF 2.0                                                                                      *
* Software by:                Bloc (http://www.tinyportal.net)                                                      *
* Copyright 2005-2012 by:     Bloc (bloc@tinyportal.net)                                                         *
* Support, News, Updates at:  http://www.tinyportal.net                   *
*******************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');
	

global $maintenance, $db_prefix, $context, $scripturl,$txt , $user_info, $settings , $modSettings, $ID_MEMBER, $boarddir, $boardurl, $options, $sourcedir;

function tp_mainmenu_construct()
{
	// make the new menu
}



?>