<?php
/****************************************************************************
* TPoptions.php																*
*****************************************************************************
* TP version: 1.0 RC1														*
* Software Version:				SMF 2.0										*
* Founder:						Bloc (http://www.blocweb.net)				*
* Developer:					IchBin (ichbin@ichbin.us)					*
* Copyright 2005-2011 by:     	The TinyPortal Team							*
* Support, News, Updates at:  	http://www.tinyportal.net					*
****************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

function TPinstallExtra()
{
	global $db_prefix, $context, $scripturl, $txt, $settings;

	// 
}

function TPinstallArticles()
{
	global $db_prefix, $context, $scripturl, $txt, $settings;


}
function TPinstallThemes()
{
	global $db_prefix, $context, $scripturl, $txt, $settings;
}



?>