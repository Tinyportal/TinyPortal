<?php
// Version: TinyPortal 1.0; TPmainmenu

$txt['permissionname_tp_mainmenu'] = 'Manage SMF\'s main menu';
$txt['permissionhelp_tp_mainmenu'] = 'Allows you to manage SMF\'s main menu.';
$txt['cannot_tp_mainmenu'] = 'Sorry, you aren\'t allowed to manage the main menu.';
$txt['tp-add'] = 'Add item';
$txt['tp-mainmenu'] = 'Main menu';

?>